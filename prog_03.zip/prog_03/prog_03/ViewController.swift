//
//  ViewController.swift
//  prog_03
//
//  Created by Germán Santos Jaimes on 11/09/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultado: UILabel!
    @IBOutlet weak var caja: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calcular(_ sender: UIButton){
        var numero = Int(caja.text!)
        if let x = numero{
            resultado.text = String(factorial(numero:x))
        }else{
            print("No hay un valor")
        }
    }
    
    func factorial(numero: Int)-> Int {
        var num = numero
        var resultado:Int = 1
        if num <= 0 {return 1}
        while num >= 1 {
            resultado = num * resultado
            num = num - 1
        }
        return resultado
    }

}


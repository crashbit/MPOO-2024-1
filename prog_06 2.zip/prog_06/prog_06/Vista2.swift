//
//  Vista2.swift
//  prog_06
//
//  Created by Germán Santos Jaimes on 18/10/23.
//

import UIKit

class Vista2: UIViewController {
    
    var alumno: String = ""
    @IBOutlet weak var letrero: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(alumno)
        letrero.text = alumno
    }

}

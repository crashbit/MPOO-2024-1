//
//  Vista2VC.swift
//  prog_5
//
//  Created by Germán Santos Jaimes on 20/09/23.
//

import UIKit

class Vista2VC: UIViewController {

    var fromView1:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(fromView1)
    }
}

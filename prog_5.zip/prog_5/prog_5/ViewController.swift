//
//  ViewController.swift
//  prog_5
//
//  Created by Germán Santos Jaimes on 20/09/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vista2 = segue.destination as! Vista2VC
        
        vista2.fromView1 = "Hola clase"
    }


}


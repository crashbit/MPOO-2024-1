//
//  Model.swift
//  Proy_Final
//
//  Created by Germán Santos Jaimes on 06/11/23.
//

import Foundation

struct Producto{
    var nombre: String
    var marca: String
    var precio: Double
    var inventario: Int
}

var productos:[Producto] = [
    Producto(nombre: "Papas", marca: "Sabritas", precio: 17, inventario: 500),
    Producto(nombre: "Refresco", marca: "Yolis", precio: 15, inventario: 100),
    Producto(nombre: "Chocolate", marca: "Abuelita", precio: 18, inventario: 200)
]

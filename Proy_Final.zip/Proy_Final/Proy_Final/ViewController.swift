//
//  ViewController.swift
//  Proy_Final
//
//  Created by Germán Santos Jaimes on 06/11/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    
    
    @IBOutlet weak var tabla: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        var producto: Producto  = productos[indexPath.row]
        
        cell.textLabel?.text = producto.nombre
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "detailSegue"){
            let vista2 = segue.destination as! DetailView
            let indexPath = tabla.indexPathForSelectedRow
            let producto = productos[indexPath!.row]
        vista2.fromViewOne = producto
        }
            else {
            let carrito = segue.destination as! CarritoView
        }
    }
    
}


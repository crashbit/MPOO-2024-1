//
//  ViewController.swift
//  Proy_Final
//
//  Created by Germán Santos Jaimes on 06/11/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


//
//  DetailView.swift
//  Proy_Final
//
//  Created by Germán Santos Jaimes on 08/11/23.
//

import UIKit

class DetailView: UIViewController {
    
    @IBOutlet weak var nombre: UILabel!
    var fromViewOne: Producto!
    @IBOutlet weak var marco: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()

        nombre.text = fromViewOne.nombre
        marco.image = UIImage(named: fromViewOne.imagen)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func comprar(_ boton:UIButton){
        
    }
}
